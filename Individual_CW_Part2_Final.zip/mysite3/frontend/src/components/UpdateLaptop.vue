<template>
    <div class="h1">
      {{title}}
    </div>
      <div class="border rounded bg-secondary shadow">
        <form @submit.prevent="update_laptop">
           <div>
            <label for="id">which laptop id do you want to change</label>
            <input type="number" id="id" v-model="id">
          </div>
          <div>
            <label for="laptop_make">laptop make</label>
            <input type="text" id="laptop_make" v-model="laptop_make">
          </div>
          <div>
            <label for="date_manufactured">Date manufactured</label>
            <input type="date" id="date_manufactured" v-model="date_manufactured">
          </div>
          <div>
            <label for="ram_size">Ram size</label>
            <input type="text" id="ram_size" v-model="ram_size">
          </div>
          <div>
            <label for="used">Is it used?</label>
            <input type="checkbox" id="used" v-model="used" />
  
          </div>
          <button class='btn btn-sm btn-success' v-on:click="update_laptop()">
            Update Laptop</button>
        </form>
      </div>
      
  </template>
  
  <script>
  
    export default{
      name: 'UpdateLaptop',
      props: ["title"],
      data(){
        return{
                laptops:[],
                id:'',
                laptop_make:'',
                date_manufactured:'',
                ram_size:0,
                used:false,
          
        }
      },
      methods: {
        async update_laptop(){
          let response = await fetch("http://localhost:8000/api/laptops/" +this.id, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              id: this.id,
              laptop_make: this.laptop_make,
              date_manufactured: this.date_manufactured,
              ram_size: this.ram_size,
              used: this.used
            }),
          });
          if (response.ok) {
            let data = await response.json();
            this.laptops = data.laptops;
          } else {
            
          }
        return response.json();
    }
            
            
      },
    }
  </script>