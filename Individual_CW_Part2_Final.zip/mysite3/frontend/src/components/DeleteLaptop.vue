<template>
    <div class="h1">
      {{title}}
    </div>
      <div class="border rounded bg-secondary shadow">
        
            <div>
              <label for="id">Which Laptop id to delete? 
              </label>
              <input type="number" id="id" v-model="id">
            </div>
          <button class='btn btn-sm btn-danger' v-on:click="deleteLaptop()">
            delete laptop</button>
            
        
      </div>
      
  </template>
  
  <script>
  
    export default{
      name: 'DeleteLaptop',
      props: ["title"],
      data(){
        return{
            laptops:[],
            id:'',
  
           
        }
      },
      methods: {
        async deleteLaptop(){
          let url = "http://localhost:8000/api/laptops/"+this.id;
                const response = await fetch(url, {
                    method: "DELETE",
                });
                let data = await response.json()
                this.laptops = data.laptops
                if (response.ok) {
                    this.laptops = this.laptops.filter(r => r.id != Laptop.id);
                    }
                else
                    alert(url);
        }
      },
    }
  </script>