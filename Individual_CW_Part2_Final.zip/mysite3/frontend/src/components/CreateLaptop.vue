<template>
  <div class="h1">
    {{title}}
  </div>
    <div class="border rounded bg-secondary shadow">
      <form>
        <div>
          <label for="laptop_make">laptop make</label>
          <input type="text" id="laptop_make" v-model="formData.laptop_make">
        </div>
        <div>
          <label for="date_manufactured">Date manufactured</label>
          <input type="date" id="date_manufactured" v-model="formData.date_manufactured">
        </div>
        <div>
          <label for="ram_size">Ram size</label>
          <input type="text" id="ram_size" v-model="formData.ram_size">
        </div>
        <div>
          <label for="used">Is it used?</label>
          <input type="checkbox" id="used" v-model="formData.used" />

        </div>
        <button class='btn btn-sm btn-success' v-on:click="createLaptop()">
          create post</button>
      </form>
    </div>
    
</template>

<script>

  export default{
    name: 'CreateLaptop',
    props: ["title"],
    data(){
      return{
         formData : {
              laptop_make:'',
              date_manufactured:'',
              ram_size:0,
              used:false,

         },
         


        
      }
    },
    methods: {
      async createLaptop(){
        const response = await fetch("http://127.0.0.1:8000/api/laptops", {
              method: 'POST',  
              headers: {
                'Content-Type': 'application/json'
                
              }, 
              body: JSON.stringify(this.formData) 
            });
            console.warn("been called", this.formData)
            return response.json();
          }
    },
  }
</script>