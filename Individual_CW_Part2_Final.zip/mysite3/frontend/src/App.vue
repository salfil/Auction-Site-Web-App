<template>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
crossorigin="anonymous">
  
  

  <div class="btn btn-primary" data-toggle="collapse" 
  href="#laptops" role="button" aria-expanded="false" aria-controls="collapseExample">

    <button v-on:click="isHidden = !isHidden" @click="fetchLaptops">Fetch Laptops</button>
    
    <div v-if="!isHidden" >
      
      <p>
        {{ laptops }}
      </p>
      
    </div>
    
  
    
    
    
    <div>
    <label for="La"></label>
      </div>
      <CreateLaptop title="Post a New Laptop" />
      <DeleteLaptop title="delete Laptop" />
      <UpdateLaptop title="Update Laptop" />
      
  </div>
</template>


<script>
import CreateLaptop from './components/CreateLaptop.vue' 
import DeleteLaptop from './components/DeleteLaptop.vue'
import UpdateLaptop from './components/UpdateLaptop.vue'

export default{
  components:{
    CreateLaptop,
    DeleteLaptop,
    UpdateLaptop,
  },
    data() {
        return {
            laptops: [],
            isHidden: false,
        };
    },
    methods: {
        async fetchLaptops() {
            //perform ajax request to fetch list of laptops
            let fetched=false
            let response = await fetch("http://127.0.0.1:8000/api/laptops");
            let data = await response.json();
            this.laptops = data;
            console.log(data.laptop_make);
            fetched=true;
            console.log(fetched)
        },
    },
    components: { CreateLaptop, DeleteLaptop, UpdateLaptop}
}
</script>

