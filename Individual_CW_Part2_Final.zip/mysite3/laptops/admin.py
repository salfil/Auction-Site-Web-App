from django.contrib import admin

from laptops.models import Laptop

# Register your models here.

admin.site.register(Laptop)
