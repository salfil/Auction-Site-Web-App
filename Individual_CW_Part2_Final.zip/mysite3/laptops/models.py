from email.policy import default
from django.db import models

# Create your models here.
class Laptop(models.Model):
    laptop_make = models.CharField(max_length=200)
    date_manufactured = models.DateField('date published')
    ram_size = models.IntegerField(default=4)
    used = models.BooleanField(default=False)

    def __str__(self):
        return self.laptop_make
        return self.date_manufactured
        return self.ram_size
        return self.used
    
    def to_dict(self):
        return {
            'id':self.id,
            'laptop_make': self.laptop_make,
            'date_manufactured': self.date_manufactured,
            'ram_size': self.ram_size,
            'used':self.used
        }


