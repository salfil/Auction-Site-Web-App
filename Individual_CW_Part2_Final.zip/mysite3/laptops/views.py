from django.shortcuts import render

from django.http.response import JsonResponse
from django.http import JsonResponse
import json
from django.http.response import HttpResponseBadRequest
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt



# Create your views here.
from django.http import HttpResponse,HttpRequest,JsonResponse
from .models import Laptop



def index(request):
    title = "My Cool Laptop API"
    return render(request, "laptops/index.html", {
        'title': title,
        'n': Laptop.objects.all().count()
    })


@csrf_exempt
def laptops_API(request):
    if request.method == 'GET':
        return JsonResponse({
            'Laptops':[
                laptop.to_dict()
                for laptop in Laptop.objects.all()
            ]
        })

    if request.method == "POST":
        data = json.load(request)
        laptop=Laptop(laptop_make=data.get('laptop_make'), 
                        date_manufactured=data.get('date_manufactured'), ram_size=data.get('ram_size'), used=data.get('used'))
        laptop.save()
        return JsonResponse({
            'Laptops':[
                laptop.to_dict()
                for laptop in Laptop.objects.all()
            ]
        })


@csrf_exempt
def laptop_API(request: HttpRequest, laptop_id) -> HttpResponse:

    if request.method == "DELETE":
        laptop = get_object_or_404(Laptop, id=laptop_id)
        laptop.to_dict()
        laptop.delete()
        return JsonResponse({})

    elif request.method == "PUT":
        data = json.loads(request.body)
        laptop = get_object_or_404(Laptop, id=laptop_id)
        laptop.laptop_make=data.get('laptop_make')
        laptop.date_manufactured=data.get('date_manufactured')
        laptop.ram_size=data.get('ram_size')
        laptop.used=data.get('used')
        #jsonResponse = json.loads(response.decode('utf-8'))
        laptop.save()
        return JsonResponse({
            laptop.to_dict()
            for laptop in Laptop.objects.all()
        })

        

    return HttpResponseBadRequest("Invalid method")

