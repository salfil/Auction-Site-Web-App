from django.urls import path

from . import views
from laptops.views import index,laptops_API

urlpatterns = [
    path('',index),
    path('api/laptops', laptops_API),
    path('api/laptop/<int:id>/', laptops_API, name="laptop api"),
]